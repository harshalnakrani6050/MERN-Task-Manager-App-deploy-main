import './App.css';
import TaskManager from './TaskManager';

function App() {
  return (
    <div className="App">
      <TaskManager />
    </div>
  );
}

export default App;
